<?php
/**
 * Created by PhpStorm.
 * User: carri_000
 * Date: 23.09.2016
 * Time: 21:24
 */

namespace Pachisi\Dice;


abstract class DiceAbstract {

    abstract public function rollDice();

}