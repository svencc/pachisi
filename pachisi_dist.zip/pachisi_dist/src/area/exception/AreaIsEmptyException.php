<?php

/**
 * Created by PhpStorm.
 * User: carri_000
 * Date: 23.09.2016
 * Time: 22:29
 */

namespace Pachisi\Area\Exception;
use Pachisi\Exception\PachisiException;

class AreaIsEmptyException extends PachisiException {

}