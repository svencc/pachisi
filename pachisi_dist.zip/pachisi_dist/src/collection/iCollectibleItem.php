<?php
/**
 * Created by PhpStorm.
 * User: carri_000
 * Date: 24.09.2016
 * Time: 12:17
 */

namespace Pachisi\Collection;


interface iCollectibleItem {

    /**
     * @return string
     */
    public function getUID();

}