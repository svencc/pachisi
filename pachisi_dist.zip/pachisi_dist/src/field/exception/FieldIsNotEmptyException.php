<?php

/**
 * Created by PhpStorm.
 * User: carri_000
 * Date: 23.09.2016
 * Time: 22:29
 */

namespace Pachisi\Field\Exception;
use Pachisi\Exception\PachisiException;

class FieldIsNotEmptyException extends PachisiException {

}