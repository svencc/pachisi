<?php

/**
 * Created by PhpStorm.
 * User: carri_000
 * Date: 23.09.2016
 * Time: 21:06
 */

namespace Pachisi\Field;
use Pachisi\Field\RegularFieldAbstract;

class StartField extends PlayerRelatedField  {

}